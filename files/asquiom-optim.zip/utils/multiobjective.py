import numpy as np


def is_non_dominated(x, maximize=False):
    if maximize:
        return (x.reshape(1, -1, 2) >= x.reshape(-1, 1, 2)).any(-1).all(0)
    else:
        return (x.reshape(1, -1, 2) <= x.reshape(-1, 1, 2)).any(-1).all(0)
