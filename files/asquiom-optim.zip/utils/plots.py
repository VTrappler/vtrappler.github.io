from matplotlib.patches import Ellipse
import matplotlib.transforms as transforms
import numpy as np


def confidence_ellipse(
    mean, cov, ax, facecolor="none", label="Confidence Ellipses", **kwargs
):
    """
    Create a plot of the covariance confidence ellipse of *x* and *y*.

    Parameters
    ----------
    x, y : array-like, shape (n, )
        Input data.

    ax : matplotlib.axes.Axes
        The Axes object to draw the ellipse into.

    n_std : float
        The number of standard deviations to determine the ellipse's radiuses.

    **kwargs
        Forwarded to `~matplotlib.patches.Ellipse`

    Returns
    -------
    matplotlib.patches.Ellipse
    """
    pearson = cov[0, 1] / np.sqrt(cov[0, 0] * cov[1, 1])
    # Using a special case to obtain the eigenvalues of this
    # two-dimensional dataset.
    ell_radius_x = np.sqrt(1 + pearson)
    ell_radius_y = np.sqrt(1 - pearson)
    for n_std in [1, 2, 3]:
        ellipse = Ellipse(
            (0, 0),
            width=ell_radius_x * 2,
            height=ell_radius_y * 2,
            facecolor=facecolor,
            alpha=1 / n_std,
            **kwargs,
            label=label if n_std == 1 else None
        )

        # Calculating the standard deviation of x from
        # the squareroot of the variance and multiplying
        # with the given number of standard deviations.
        scale_x = np.sqrt(cov[0, 0]) * n_std

        # calculating the standard deviation of y ...
        scale_y = np.sqrt(cov[1, 1]) * n_std

        transf = (
            transforms.Affine2D()
            .rotate_deg(45)
            .scale(scale_x, scale_y)
            .translate(mean[0], mean[1])
        )

        ellipse.set_transform(transf + ax.transData)
        ax.add_patch(ellipse)
    return ax, ellipse
