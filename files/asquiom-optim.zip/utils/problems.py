from dataclasses import dataclass
import numpy as np  # pyright: ignore[reportMissingImports]
import matplotlib.pyplot as plt  # pyright: ignore[reportMissingImports]

## Monter en dimension


@dataclass
class OptimFunction:
    bounds: list[list[float]]
    dim: int

    def __init__(self):
        pass

    def __call__(self, x: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def grad(self, x):
        raise NotImplementedError

    def meshgrid(self, n_pts):
        x_, y_ = (
            np.linspace(self.bounds[0][0], self.bounds[1][0], n_pts),
            np.linspace(self.bounds[0][1], self.bounds[1][1], n_pts),
        )
        x_mg, y_mg = np.meshgrid(x_, y_)
        xy = np.stack([x_mg, y_mg]).reshape(2, -1).T
        return xy, x_mg, y_mg

    def plot_function(
        self, n_pts, cmap=plt.get_cmap("magma"), with_grad=False, ax=None, levels=50
    ):
        if self.dim == 2:
            xy, x_mg, y_mg = self.meshgrid(n_pts)
            if ax is None:
                cmap = plt.contourf(
                    x_mg,
                    y_mg,
                    self.__call__(xy).reshape(n_pts, n_pts),
                    cmap=cmap,
                    levels=levels,
                )
                if with_grad:
                    try:
                        grads = self.grad(xy).reshape(n_pts, n_pts, 2)
                        plt.quiver(x_mg, y_mg, grads[..., 0], grads[..., 1])
                    except NotImplementedError:
                        print("No gradient implemented")
            else:
                cmap = ax.contourf(
                    x_mg,
                    y_mg,
                    self.__call__(xy).reshape(n_pts, n_pts),
                    cmap=cmap,
                    levels=levels,
                )
                if with_grad:
                    try:
                        grads = self.grad(xy).reshape(n_pts, n_pts, 2)
                        ax.quiver(x_mg, y_mg, grads[..., 0], grads[..., 1])
                    except NotImplementedError:
                        print("No gradient implemented")
            return cmap
        else:
            raise NotImplementedError

    def plot_norm_grad(self, n_pts, cmap=plt.get_cmap("magma"), ax=None, levels=50):
        if self.dim == 2:
            xy, x_mg, y_mg = self.meshgrid(n_pts)
            if ax is None:
                cmap = plt.contourf(
                    x_mg,
                    y_mg,
                    grads=(self.grad(xy).reshape(n_pts, n_pts, 2) ** 2).sum(1),
                    cmap=cmap,
                    levels=levels,
                )
            else:
                cmap = ax.contourf(
                    x_mg,
                    y_mg,
                    (self.grad(xy).reshape(n_pts, n_pts, 2) ** 2).sum(2),
                    cmap=cmap,
                    levels=levels,
                )
            return cmap
        else:
            raise NotImplementedError

    def generate_random_x0(self, n_samples=1):
        bounds = np.asarray(self.bounds)
        return (
            np.random.uniform(size=(n_samples, self.dim)) * (bounds[1] - bounds[0])
            + bounds[0]
        )


class OneDim(OptimFunction):
    dim = 1
    bounds = [[0], [10]]
    xstar = np.array([[7.97866]])
    fstar = -6.9167273

    def __call__(self, x):
        return 1 - np.sin(x) * x

    def grad(self, x):
        return -np.sin(x) - x * np.cos(x)


class Sphere(OptimFunction):
    dim: int = 2
    bounds = [[-2, -2], [2, 2]]
    fstar = 0.0
    xstar = np.array([[0.0, 0.0]])

    def __call__(self, x):
        return (x**2).sum(1)

    def grad(self, x):
        return 2 * x


class NdSphere(OptimFunction):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim


class IllConditioned(OptimFunction):
    dim: int = 2
    bounds = [[0, 0], [3, 3]]
    A = np.array([[50, 0], [0, 1]])
    fstar = 0.0
    xstar = np.array([[1.0, 1.0]])

    def __init__(self):
        pass

    def __call__(self, x):
        return np.einsum("ij,ij->i", (x - 1) @ self.A, x - 1)
        # x has shape (batch, 2)
        # return np.einsum("bd,dd,db->b", (x - 1.0), self.A, (x - 1.0).T)

    def grad(self, x):
        # x has shape (batch, 2)
        # Gradient: 2 * (x - 1) @ A.T
        return 2 * (x - 1.0) @ self.A.T


class Easom(OptimFunction):
    bounds = [[-30, -30], [30, 30]]
    dim: int = 2
    xstar = np.array([[np.pi, np.pi]])
    fstar = -1

    def __call__(self, x):
        return (
            -np.cos(x[:, 0])
            * np.cos(x[:, 1])
            * np.exp(-((x[:, 0] - np.pi) ** 2) - (x[:, 1] - np.pi) ** 2)
        )

    def grad(self, x):
        term = np.exp(-((x[:, 0] - np.pi) ** 2) - (x[:, 1] - np.pi) ** 2)
        df_dx0 = (
            np.sin(x[:, 0]) * np.cos(x[:, 1]) * term
            + 2 * np.cos(x[:, 0]) * np.cos(x[:, 1]) * (x[:, 0] - np.pi) * term
        )
        df_dx1 = (
            np.cos(x[:, 0]) * np.sin(x[:, 1]) * term
            + 2 * np.cos(x[:, 0]) * np.cos(x[:, 1]) * (x[:, 1] - np.pi) * term
        )
        return np.stack((df_dx0, df_dx1), axis=1)


class NeuralNetwork(OptimFunction):
    #
    pass


class DixonPrice(OptimFunction):
    bounds = [[-10, -10], [10, 10]]
    dim: int = 2
    fstar = 0
    xstar = np.array([[1, 0.5]])

    def __call__(self, x):
        return (x[:, 0] - 1) ** 2 + 2 * (2 * x[:, 1] ** 2 - x[:, 0]) ** 2

    def grad(self, x):
        df_dx0 = 2 * (x[:, 0] - 1) - 4 * (2 * x[:, 1] ** 2 - x[:, 0])
        df_dx1 = 16 * x[:, 1] * (2 * x[:, 1] ** 2 - x[:, 0])
        return np.stack((df_dx0, df_dx1), axis=1)


class SixHumpCamel(OptimFunction):
    bounds = [[-3, -2], [3, 2]]
    dim: int = 2
    fstar = -1.0316
    xstar = np.array([[0.0898, -0.7126]])
    xstar2 = np.array([[-0.0898, 0.7126]])

    def __call__(self, x):
        return (
            (4 - 2.1 * x[:, 0] ** 2 + (x[:, 0] ** 4) / 3) * x[:, 0] ** 2
            + x[:, 0] * x[:, 1]
            + (-4 + 4 * x[:, 1] ** 2) * x[:, 1] ** 2
        )

    def grad(self, x):
        df_dx0 = 8 * x[:, 0] - 8.4 * x[:, 0] ** 3 + 2 * x[:, 0] ** 5 + x[:, 1]
        df_dx1 = x[:, 0] - 8 * x[:, 1] + 16 * x[:, 1] ** 3
        return np.stack((df_dx0, df_dx1), axis=1)


class Michalewicz2d(OptimFunction):
    bounds = [[0, 0], [np.pi, np.pi]]
    dim: int = 2
    fstar: float = -1.8013
    xstar = np.array([[2.20, 1.57]])

    def __call__(self, x):
        return -np.sin(x[:, 0]) * np.sin(x[:, 0] ** 2 / np.pi) ** (2 * 10) - np.sin(
            x[:, 1]
        ) * np.sin(2 * x[:, 1] ** 2 / np.pi) ** (2 * 10)

    def grad(self, x):
        # Dérivée partielle par rapport à x0
        sin_x0_sq = np.sin(x[:, 0] ** 2 / np.pi)
        cos_x0_sq = np.cos(x[:, 0] ** 2 / np.pi)
        df_dx0 = -(
            np.cos(x[:, 0]) * sin_x0_sq**20
            + np.sin(x[:, 0]) * 20 * sin_x0_sq**19 * cos_x0_sq * (2 * x[:, 0] / np.pi)
        )

        # Dérivée partielle par rapport à x1
        sin_x1_sq = np.sin(2 * x[:, 1] ** 2 / np.pi)
        cos_x1_sq = np.cos(2 * x[:, 1] ** 2 / np.pi)
        df_dx1 = -(
            np.cos(x[:, 1]) * sin_x1_sq**20
            + np.sin(x[:, 1]) * 20 * sin_x1_sq**19 * cos_x1_sq * (4 * x[:, 1] / np.pi)
        )

        return np.stack((df_dx0, df_dx1), axis=1)


class Ackley(OptimFunction):
    bounds = [[-32.768, -32.768], [32.768, 32.768]]
    a = 20.0
    b = 0.2
    c = 2 * np.pi
    fstar = 0.0
    xstar = np.array([[0.0, 0.0]])
    dim: int = 2

    def __call__(self, x):
        return (
            -self.a * np.exp(-self.b * np.sqrt(np.sum(x**2, 1) / 2))
            - np.exp(np.cos(self.c * x).sum(1) / 2)
            + self.a
            + np.exp(1)
        )

    def grad(self, x):
        norm = np.sqrt(np.sum(x**2, 1))
        exp_term1 = np.exp(-self.b * norm / np.sqrt(2))
        grad_term1 = (self.a * self.b * exp_term1 * x.T / (norm * np.sqrt(2))).T

        cos_term = np.cos(self.c * x)
        exp_term2 = np.exp(cos_term.sum(1) / 2)
        grad_term2 = self.c / 2 * np.sin(self.c * x) * exp_term2[:, np.newaxis]

        return grad_term1 + grad_term2


class Booth(OptimFunction):
    bounds = [[-10.0, -10.0], [10.0, 10.0]]
    fstar = 0.0
    xstar = np.array([[1.0, 3.0]])
    dim: int = 2

    def __call__(self, x):
        return (x[:, 0] + 2 * x[:, 1] - 7) ** 2 + (2 * x[:, 0] + x[:, 1] - 5) ** 2

    def grad(self, x):
        df_dx0 = 10 * x[:, 0] + 8 * x[:, 1] - 34
        df_dx1 = 8 * x[:, 0] + 10 * x[:, 1] - 38
        return np.stack((df_dx0, df_dx1), axis=1)


class McCormick(OptimFunction):
    bounds = [[-1.5, -3], [4, 4]]
    fstar = -1.9133
    xstar = np.array([[-0.54719, -1.54719]])
    dim: int = 2

    def __call__(self, x):
        return (
            np.sin(x[:, 0] + x[:, 1])
            + (x[:, 0] - x[:, 1]) * (x[:, 0] - 2.5 * x[:, 1] + 1) ** 2
            + 0.1 * (x[:, 0] + 3 * x[:, 1] - 3) ** 2
        )

    def grad(self, x):
        term1 = x[:, 0] - 2.5 * x[:, 1] + 1
        term2 = x[:, 0] + 3 * x[:, 1] - 3

        df_dx0 = (
            np.cos(x[:, 0] + x[:, 1])
            + term1**2
            + 2 * (x[:, 0] - x[:, 1]) * term1
            + 0.2 * term2
        )

        df_dx1 = (
            np.cos(x[:, 0] + x[:, 1])
            - term1**2
            - 5 * (x[:, 0] - x[:, 1]) * term1
            + 0.6 * term2
        )

        return np.stack((df_dx0, df_dx1), axis=1)


class ThreeHumpCamel(OptimFunction):
    bounds = [[-5.0, -5.0], [5.0, 5.0]]
    fstar = 0
    xstar = np.array([[0.0, 0.0]])
    dim: int = 2

    def __call__(self, x):
        return (
            2 * x[:, 0] ** 2
            - 1.05 * x[:, 0] ** 4
            + (x[:, 0] ** 6) / 6.0
            + x[:, 0] * x[:, 1]
            + x[:, 1] ** 2
        )

    def grad(self, x):
        df_dx0 = 4 * x[:, 0] - 4.2 * x[:, 0] ** 3 + x[:, 0] ** 5 + x[:, 1]
        df_dx1 = x[:, 0] + 2 * x[:, 1]
        return np.stack((df_dx0, df_dx1), axis=1)


class Branin(OptimFunction):
    bounds = [[-5.0, 0], [10, 15]]
    dim: int = 2
    fstar = -1.9133
    xstar = np.array([[-np.pi, 12.275]])
    xstar2 = np.array([[np.pi, 2.275]])
    xstar3 = np.array([[9.42478, 2.475]])

    def __call__(self, x):
        t1 = x[:, 1] - 5.1 / (4 * np.pi**2) * x[:, 0] ** 2 + 5 / np.pi * x[:, 0] - 6
        t2 = 10 * (1 - 1 / (8 * np.pi)) * np.cos(x[:, 0])
        return t1**2 + t2 + 10

    def grad(self, x):
        t1 = x[:, 1] - 5.1 / (4 * np.pi**2) * x[:, 0] ** 2 + 5 / np.pi * x[:, 0] - 6
        df_dx0 = 2 * t1 * (-5.1 / (2 * np.pi**2) * x[:, 0] + 5 / np.pi) - 10 * (
            1 - 1 / (8 * np.pi)
        ) * np.sin(x[:, 0])
        df_dx1 = 2 * t1
        return np.stack((df_dx0, df_dx1), axis=1)


class Trid(OptimFunction):
    def __init__(self, dim=5):
        super().__init__()
        self.dim = dim
        self.bounds = [  # pyright: ignore[reportAttributeAccessIssue]
            self.dim * [-self.dim**2],
            self.dim * [self.dim**2],
        ]
        self.fstar = -self.dim * (self.dim + 4) * (self.dim - 1) / 6
        self.xstar = np.array([[(i + 1) * (self.dim - i) for i in range(self.dim)]])

    def __call__(self, x):
        return np.sum((x - 1) ** 2, 1) - (x[:, 1:] * x[:, :-1]).sum(1)

    def grad(self, x):
        grad = 2 * (x - 1)
        grad[:, 1:-1] -= x[:, :-2] + x[:, 2:]
        grad[:, 0] -= x[:, 1]
        grad[:, -1] -= x[:, -2]
        return grad


class Griewank(OptimFunction):
    def __init__(self, dim=5):
        super().__init__()
        self.dim = dim
        self.bounds = [self.dim * [-600.0], self.dim * [600.0]]
        self.fstar = 0.0
        self.xstar = np.zeros(self.dim).reshape(1, self.dim)

    def __call__(self, x):
        return (
            np.sum(x**2 / 4000, 1)
            - np.cos(x / (np.sqrt(np.arange(self.dim) + 1).reshape(1, self.dim))).prod(
                1
            )
            + 1
        )

    def grad(self, x):
        # Calcul du produit des cosinus
        sqrt_indices = np.sqrt(np.arange(self.dim) + 1).reshape(1, self.dim)
        cos_terms = np.cos(x / sqrt_indices)
        product_cos = cos_terms.prod(1)

        # Initialisation du gradient
        grad = np.zeros_like(x)

        # Calcul de la dérivée pour chaque x_j
        for j in range(self.dim):
            # Termes pour la dérivée du produit des cosinus
            sin_term = np.sin(x[:, j] / sqrt_indices[:, j])
            cos_product_without_j = product_cos / cos_terms[:, j]

            # Dérivée totale pour x_j
            grad[:, j] = (
                x[:, j] / 2000 + sin_term * cos_product_without_j / sqrt_indices[:, j]
            )

        return grad


class Zakharov(OptimFunction):
    def __init__(self, dim=5):
        super().__init__()
        self.dim = dim
        self.bounds = [self.dim * [-5.0], self.dim * [10.0]]
        self.fstar = 0.0
        self.xstar = np.zeros(self.dim).reshape(1, self.dim)

    def __call__(self, x):
        iis = (np.arange(self.dim) + 1).reshape(1, self.dim)
        return (
            np.sum(x**2, 1)
            + np.sum(0.5 * iis * x, 1) ** 2
            + np.sum(0.5 * iis * x, 1) ** 4
        )

    def grad(self, x):
        iis = (np.arange(self.dim) + 1).reshape(1, self.dim)
        S = np.sum(0.5 * iis * x, 1)
        grad = 2 * x + iis * (S + 2 * S**3)[:, np.newaxis]
        return grad


class Rosenbrock(OptimFunction):
    def __init__(self, dim=5):
        super().__init__()
        self.dim = dim
        self.bounds = [self.dim * [-5.0], self.dim * [10.0]]
        self.fstar = 0.0
        self.xstar = np.ones(self.dim).reshape(1, self.dim)

    def __call__(self, x):
        return np.sum(100 * (x[:, 1:] - x[:, :-1] ** 2) ** 2 + (x[:, :-1] - 1) ** 2, 1)

    def grad(self, x):
        grad = np.zeros_like(x)
        grad[:, 0] = -400 * x[:, 0] * (x[:, 1] - x[:, 0] ** 2) + 2 * (x[:, 0] - 1)
        grad[:, -1] = 200 * (x[:, -1] - x[:, -2] ** 2)
        for j in range(1, self.dim - 1):
            grad[:, j] = (
                200 * (x[:, j] - x[:, j - 1] ** 2)
                - 400 * x[:, j] * (x[:, j + 1] - x[:, j] ** 2)
                + 2 * (x[:, j] - 1)
            )
        return grad


class Rosenbrock2d(OptimFunction):
    dim = 2

    def __init__(self):
        super().__init__()
        self.bounds = [self.dim * [-1.0], self.dim * [3.0]]
        self.fstar = 0.0
        self.xstar = np.ones(self.dim).reshape(1, self.dim)

    def __call__(self, x):
        return np.sum(100 * (x[:, 1:] - x[:, :-1] ** 2) ** 2 + (x[:, :-1] - 1) ** 2, 1)

    def grad(self, x):
        grad = np.zeros_like(x)
        grad[:, 0] = -400 * x[:, 0] * (x[:, 1] - x[:, 0] ** 2) + 2 * (x[:, 0] - 1)
        grad[:, -1] = 200 * (x[:, -1] - x[:, -2] ** 2)
        for j in range(1, self.dim - 1):
            grad[:, j] = (
                200 * (x[:, j] - x[:, j - 1] ** 2)
                - 400 * x[:, j] * (x[:, j + 1] - x[:, j] ** 2)
                + 2 * (x[:, j] - 1)
            )
        return grad


class RotatedHyperEllipsoid(OptimFunction):
    def __init__(self, dim=5):
        super().__init__()
        self.dim = dim
        self.bounds = [self.dim * [-65.536], self.dim * [65.536]]
        self.fstar = 0.0
        self.xstar = np.zeros(self.dim).reshape(1, self.dim)

    def __call__(self, x):
        return np.array([(x[:, : i + 1] ** 2).sum(1) for i in range(self.dim)]).sum(0)

    def grad(self, x):
        weights = (self.dim - np.arange(self.dim)).reshape(1, self.dim)
        return 2 * x * weights


# class Perm0db(OptimFunction):
#     def __init__(self, dim=5, beta=10):
#         super().__init__()
#         self.dim = dim
#         self.bounds = [self.dim * [-float(self.dim)], self.dim * [float(self.dim)]]
#         self.fstar = 0.0
#         self.xstar = (1 / (np.arange(self.dim) + 1)).reshape(1, self.dim)
#         self.beta = 10

#     def __call__(self, x):
